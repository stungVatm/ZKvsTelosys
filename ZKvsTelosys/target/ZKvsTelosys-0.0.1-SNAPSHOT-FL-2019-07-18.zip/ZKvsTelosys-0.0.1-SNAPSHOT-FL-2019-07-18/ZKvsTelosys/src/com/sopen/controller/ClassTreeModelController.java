package com.sopen.controller;

import java.util.LinkedList;
import java.util.List;

import org.demo.data.record.ClassestreeRecord;
import org.demo.persistence.impl.jdbc.ClassestreePersistenceJdbc;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Button;
import org.zkoss.zul.Div;
import org.zkoss.zul.Label;
import org.zkoss.zul.Tree;
import org.zkoss.zul.TreeModel;
import org.zkoss.zul.TreeNode;
import org.zkoss.zul.Window;
import org.zkoss.zul.event.TreeDataListener;

import bsh.Console;

public class ClassTreeModelController extends SelectorComposer<Component> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Wire
	@Wire
	Div showLists;
	@Wire
	Tree showTree;
	@Wire
	Button btnNewRecord;
	@Wire
	Window wdClassesTreeModel_Detail;
	
	// Declare
	ClassestreePersistenceJdbc clsTrPerJDBC = new ClassestreePersistenceJdbc();
	List<ClassestreeRecord> list = clsTrPerJDBC.findAll();
	int lever=0;
	private TreeModel<TreeNode<ClassestreeRecord>> categoriesModel;
	private Window detail;
	
	@Override
	public void doAfterCompose(Component comp) throws Exception {
		super.doAfterCompose(comp);
		loadData(lever, 0);
//		loadDataPlus();
	}

	private void loadData(int lever, int parent) {	
		for (ClassestreeRecord record : searchChildren(parent)) {
			String space = "";
			for (int i = 0; i < lever; i++) {
				space += "...............................";
			}
			Label lb = new Label(space + record.getNamecl()+"(ID:"+record.getId()+")");
			lb.setParent(showLists);
			// xuong dong
			org.zkoss.zul.Separator enter = new org.zkoss.zul.Separator();
			enter.setParent(showLists);
			loadData(lever + 1, record.getId());
		}

	}
	
	private List<ClassestreeRecord> searchChildren(int idParent) {
		
		List<ClassestreeRecord> listChildren = new LinkedList<ClassestreeRecord>();
		for (int i = 0; i < list.size(); i++) {
			ClassestreeRecord record = list.get(i);
			if (record.getIdperent()==null) {
				record.setIdperent(0);
			}
			if (record.getIdperent()==idParent) {
				listChildren.add(record);
			}
		}
		return listChildren;
	}
	
	@Listen("onClick = #btnNewRecord")
	public void createNew() {		
		detail = (Window) Executions.createComponents("/Zul/ClassesTree/ClassesTreeModel_Detail.zul", null, null);
		((ClassesTreeModelDetailController)detail.getAttribute("Controller")).setRecord(new ClassestreeRecord());
		((ClassesTreeModelDetailController)detail.getAttribute("Controller")).setClsTrModelCtr(this);
		detail.doModal();
		detail.setParent(wdClassesTreeModel_Detail);
	}


	public void refresh() {
		showLists.getChildren().clear();
		lever = 0;
		list = clsTrPerJDBC.findAll();
		loadData(lever,0);
	}
}
