 package com.sopen.controller;

import org.demo.data.record.ScoresRecord;
import org.demo.data.record.StudentsRecord;
import org.demo.persistence.impl.jdbc.ScoresPersistenceJdbc;
import org.demo.persistence.impl.jdbc.SubjectsPersistenceJdbc;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Label;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Listcell;
import org.zkoss.zul.Listitem;
import org.zkoss.zul.ListitemRenderer;
import org.zkoss.zul.Window;

import com.sopen.controller.StudentsListController.StudentsListItemRenderer;

public class StudentsScoreController extends SelectorComposer<Component> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StudentsRecord getStRec() {
		return stRec;
	}

	public void setStRec(StudentsRecord stRec) {
		this.stRec = stRec;
		if (stRec != null) {

			LoadData();
		}
	}

	// Para
	private StudentsRecord stRec;
	private ScoresPersistenceJdbc scPerJDPC = new ScoresPersistenceJdbc();
	private SubjectsPersistenceJdbc sbPerJDPC = new SubjectsPersistenceJdbc();

	// Wire
	@Wire
	Window wdScoreStudents;
	@Wire
	Label testRc;
	@Wire
	Listbox lstBox;
	@Wire
	Label avgScore;
	@Wire
	Label lblRank;
	@Override
	public void doAfterCompose(Component comp) throws Exception {
		// TODO Auto-generated method stub
		super.doAfterCompose(comp);
		wdScoreStudents.setAttribute("Controller", this);
		lstBox.setItemRenderer(new ScoresListItemRenderer());
	}

	public void LoadData() {
		ListModelList<ScoresRecord> model = new ListModelList<ScoresRecord>(scPerJDPC.findByStudentID(stRec.getId()));
		lstBox.setModel(model);
		testRc.setValue(stRec.getNamest());
		avgScore.setValue(avgScore(model)+"");
		lblRank.setValue(getRank(avgScore(model)));
		
	}
	
	// return Average
	public double avgScore(ListModelList<ScoresRecord> model) {
		double totalScore = 0.0;
		int totalFactor = 0;
		for (ScoresRecord t : model) {
			double Score = t.getScore();
			int Factor = sbPerJDPC.findById(t.getSubjectid()).getFactor();
			totalScore += Score * Factor;
			totalFactor += Factor;
		}
		return totalScore/totalFactor;
	}
	// return Rank
	public String getRank(double avgScore) {
		if (avgScore>8.5) {
			return "top";
		} else if (avgScore>6.5) {
			return "Medium";
		} else {
			return "Buttom";
		}
	}
	
	class ScoresListItemRenderer implements ListitemRenderer<ScoresRecord> {

		public void render(Listitem item, ScoresRecord data, int index) throws Exception {
			Listcell cell = new Listcell((index + 1) + "");
			cell.setParent(item);
			cell = new Listcell(sbPerJDPC.findById(data.getSubjectid()).getNamesu());
			cell.setParent(item);
			cell = new Listcell(sbPerJDPC.findById(data.getSubjectid()).getFactor() + "");
			cell.setParent(item);
			cell = new Listcell(data.getScore() + "");
			cell.setParent(item);

		}

	}
}
